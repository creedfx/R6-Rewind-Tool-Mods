Open the CT
Go to edit -> settings -> plugins
Click "Add new" 
Select umstealthedit-x86_64.dll
Make sure the checkbox is checked
Click OK

If you do not do this it will not work.

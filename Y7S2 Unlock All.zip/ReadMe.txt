Setup Instructions
Install Cheat Engine from the official website
Extract StealthEdit 2.4.2.zip to C:\Program Files\Cheat Engine\plugins
Open Cheat Engine → Edit → Settings → Plugins → Add new
Select umstealthedit-x86_64.dll (for 64-bit systems), and click Open
Check the plugin checkbox, then click OK
Usage Instructions
Launch Rainbow Six Siege (build 43489433)
Open Cheat Engine and select RainbowSix.exe from the process list
Open Y7S2 Unlocker.ct
Check the Unlock All Cosmetics checkbox to activate
 
